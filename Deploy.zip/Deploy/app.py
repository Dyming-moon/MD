from flask import Flask, render_template, request
import numpy as np
import pandas as pd
import re

app = Flask(__name__)

@app.route('/index/', methods=['get', 'post'])
def index():
    if request.method == 'GET':
        return render_template("CreditScore.html")
    elif request.method == 'POST':
        feature_dict = {}
        with open('./score.txt', 'r') as file:
            score_data = file.readlines()
        current_feature = None
        data = []

        for line in score_data:
            line = line.strip()

            if "Name: " in line:
                data = []
                current_feature = re.sub(r',.*', '', line.split('Name: ')[1].strip())

            if re.match(r'[\(\[].*[\)\]]', line):
                parts = line.split()
                interval_start = float(parts[0].strip('(,'))
                interval_end = float(parts[1].strip(')'))
                score = float(parts[2])
                data.append((interval_start, interval_end, score))
            df = pd.DataFrame(data, columns=['Start', 'End', 'Score'])
            df['Start'] = df['Start'].replace('-inf', -np.inf).astype(float)
            df['End'] = df['End'].replace('inf', np.inf).astype(float)
            feature_dict[current_feature] = df


        user = {
            "RevolvingUtilizationOfUnsecuredLines": float(request.form.get('RevolvingUtilizationOfUnsecuredLines')),
            "age": float(request.form.get('age')),
            "NumberOfTime30-59DaysPastDueNotWorse": float(request.form.get('NumberOfTime30-59DaysPastDueNotWorse')),
            "DebtRatio": float(request.form.get('DebtRatio')),
            "NumberOfTime90DaysLate": float(request.form.get('NumberOfTime90DaysLate')),
            "NumberOfTime60-89DaysPastDueNotWorse": float(request.form.get('NumberOfTime60-89DaysPastDueNotWorse'))
        }

        total_score = 0
        basic_score = 481.1783273722227
        for feature, value in user.items():
            if feature in feature_dict:
                df = feature_dict[feature]
                user_score = df[(df['Start'] < value) & (df['End'] >= value)]['Score'].values[0]
                total_score += user_score

        total_score += basic_score
        total_score = round(total_score)

        if total_score < 400:
            credit_rate = 'D'
        elif total_score <= 450:
            credit_rate ='C'
        elif total_score <= 500:
            credit_rate ='B'
        else:
            credit_rate ='A'

        print(f"The score this customer gets:{total_score}, therefore, credit rate is:{credit_rate}")
        return f"The score this customer gets:{total_score}, therefore, credit rate is:{credit_rate}"


if __name__ == "__main__":
    app.run(debug=True)